#!/bin/bash

# Name des C-Quellcodes
source_file="v_0_1-Kirsche.c"

# Name der ausführbaren Datei
output_file="v_0_1-Kirsche"

# Kompilieren des C-Quellcodes
gcc "v_0_1-Kirsche.c" -o "v_0_1-Kirsche"

if [ $? -eq 0 ]; then
    echo "Kompilierung erfolgreich. Die ausführbare Datei wurde erstellt: v_0_1-Kirsche"
else
    echo "Kompilierung fehlgeschlagen."
fi

