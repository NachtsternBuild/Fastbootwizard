#!/bin/bash

echo "Um den C-Quellcode auszuführen, müssen ein Kompiler, die ADB, und Fastboot-Tools installiert sein"

read -p "Drücken sie 'i' um diese Tools zu installieren (nur für Ubuntu und Debian Systeme). Drücken 'f' fortzufahren wenn die Tools schon installiert sind." vorher

if [ "$vorher" = 'i' ] || [ "$vorher" = 'I' ]; then 
	echo "Benötigte Tools werden installiert..."
	sudo apt update 
	sudo apt install build-essential 
	sudo apt install android-tools-adb
	sudo apt install android-tools-fastboot

else 
	# Name des C-Quellcodes
	source_file="v_0_1-Kirsche.c"

	# Name der ausführbaren Datei
	output_file="v_0_1-Kirsche"

	# Kompilieren des C-Quellcodes
	gcc "v_0_1-Kirsche.c" -o "v_0_1-Kirsche"

	if [ $? -eq 0 ]; then
   	 	echo "Kompilierung erfolgreich. Ausführen des Programms..."
    		# Ausführen der ausführbaren Datei
    		"./v_0_1-Kirsche"
	else
    		echo "Kompilierung fehlgeschlagen. der Programmierer ist Schuld."
    	fi

fi

