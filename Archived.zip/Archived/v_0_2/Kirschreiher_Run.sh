#!/bin/bash

# Name des C-Quellcodes
source_file="v_0_2-Kirschreiher.c"

# Name der ausführbaren Datei
output_file="v_0_2-Kirschreiher"

# Kompilieren des C-Quellcodes
gcc "v_0_2-Kirschreiher.c" -o "v_0_2-Kirschreiher"

if [ $? -eq 0 ]; then
    echo "Kompilierung erfolgreich. Führe das Programm aus..."
    # Ausführen der ausführbaren Datei
    "./v_0_2-Kirschreiher"
else
    echo "Kompilierung fehlgeschlagen."
fi

