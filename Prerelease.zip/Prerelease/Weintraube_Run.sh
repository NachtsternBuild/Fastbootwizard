#!/bin/bash

# Name des C-Quellcodes
source_file="v_0_3-Weintraube_de.c"

# Name der ausführbaren Datei
output_file="v_0_3-Weintraube_de"

# Kompilieren des C-Quellcodes
gcc "v_0_3-Weintraube_de.c" -o "v_0_3-Weintraube_de"

if [ $? -eq 0 ]; then
    echo "Kompilierung erfolgreich. Führe das Programm aus..."
    # Ausführen der ausführbaren Datei
    "./v_0_3-Weintraube_de"
else
    echo "Kompilierung fehlgeschlagen."
fi

