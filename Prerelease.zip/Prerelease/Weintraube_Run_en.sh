#!/bin/bash

source_file="v_0_3-Weintraube_en.c"

output_file="v_0_3-Weintraube_en"

gcc "v_0_3-Weintraube_en.c" -o "v_0_3-Weintraube_en"

if [ $? -eq 0 ]; then
    echo "Compilation successful. Program is executing..."
    "./v_0_3-Weintraube_en"
else
    echo "The compilation failed!"
fi

